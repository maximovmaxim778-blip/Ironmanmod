package com.ironmanmod.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> owning client only: current suit energy, for the HUD bar. */
public class S2CSyncEnergyPacket {

    private final int energy;
    private final int maxEnergy;

    public S2CSyncEnergyPacket(int energy, int maxEnergy) {
        this.energy = energy;
        this.maxEnergy = maxEnergy;
    }

    public static void encode(S2CSyncEnergyPacket packet, FriendlyByteBuf buffer) {
        buffer.writeInt(packet.energy);
        buffer.writeInt(packet.maxEnergy);
    }

    public static S2CSyncEnergyPacket decode(FriendlyByteBuf buffer) {
        return new S2CSyncEnergyPacket(buffer.readInt(), buffer.readInt());
    }

    public static void handle(S2CSyncEnergyPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                com.ironmanmod.client.IronManHudOverlay.setEnergy(packet.energy, packet.maxEnergy)));
        context.setPacketHandled(true);
    }
}
