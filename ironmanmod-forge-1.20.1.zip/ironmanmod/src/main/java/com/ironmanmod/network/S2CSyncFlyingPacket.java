package com.ironmanmod.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * Server -> all tracking clients: "this entity is/isn't suit-flying right
 * now". Lets the armor model pick the flight pose for ANY player wearing the
 * suit, not just the local one (isFallFlying() alone only covers elytra).
 *
 * The actual client-side map write happens inside DistExecutor.unsafeRunWhenOn
 * so the client-only class (client.FlightRenderState) is never touched from
 * code that could run on a dedicated server.
 */
public class S2CSyncFlyingPacket {

    private final UUID entityId;
    private final boolean flying;

    public S2CSyncFlyingPacket(UUID entityId, boolean flying) {
        this.entityId = entityId;
        this.flying = flying;
    }

    public static void encode(S2CSyncFlyingPacket packet, FriendlyByteBuf buffer) {
        buffer.writeUUID(packet.entityId);
        buffer.writeBoolean(packet.flying);
    }

    public static S2CSyncFlyingPacket decode(FriendlyByteBuf buffer) {
        return new S2CSyncFlyingPacket(buffer.readUUID(), buffer.readBoolean());
    }

    public static void handle(S2CSyncFlyingPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                com.ironmanmod.client.FlightRenderState.set(packet.entityId, packet.flying)));
        context.setPacketHandled(true);
    }
}
