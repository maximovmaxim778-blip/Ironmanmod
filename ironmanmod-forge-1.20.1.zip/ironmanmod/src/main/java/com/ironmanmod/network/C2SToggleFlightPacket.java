package com.ironmanmod.network;

import com.ironmanmod.common.SuitAbilityHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: "player pressed the flight-toggle key". No payload needed. */
public class C2SToggleFlightPacket {

    public C2SToggleFlightPacket() {
    }

    public static void encode(C2SToggleFlightPacket packet, FriendlyByteBuf buffer) {
        // no fields
    }

    public static C2SToggleFlightPacket decode(FriendlyByteBuf buffer) {
        return new C2SToggleFlightPacket();
    }

    public static void handle(C2SToggleFlightPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                SuitAbilityHandler.toggleFlight(player);
            }
        });
        context.setPacketHandled(true);
    }
}
