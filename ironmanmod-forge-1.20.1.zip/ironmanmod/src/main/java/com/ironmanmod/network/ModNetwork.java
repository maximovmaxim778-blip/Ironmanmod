package com.ironmanmod.network;

import com.ironmanmod.IronManMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * Central packet channel. Registers every C2S/S2C message the suit needs.
 * Call ModNetwork.register() once from the mod constructor.
 */
public final class ModNetwork {

    private static final String PROTOCOL_VERSION = "1";
    private static int nextId = 0;

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(IronManMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private ModNetwork() {
    }

    public static void register() {
        CHANNEL.registerMessage(nextId++, C2SToggleFlightPacket.class,
                C2SToggleFlightPacket::encode, C2SToggleFlightPacket::decode, C2SToggleFlightPacket::handle);

        CHANNEL.registerMessage(nextId++, C2SRepulsorBlastPacket.class,
                C2SRepulsorBlastPacket::encode, C2SRepulsorBlastPacket::decode, C2SRepulsorBlastPacket::handle);

        CHANNEL.registerMessage(nextId++, S2CSyncFlyingPacket.class,
                S2CSyncFlyingPacket::encode, S2CSyncFlyingPacket::decode, S2CSyncFlyingPacket::handle);

        CHANNEL.registerMessage(nextId++, S2CSyncEnergyPacket.class,
                S2CSyncEnergyPacket::encode, S2CSyncEnergyPacket::decode, S2CSyncEnergyPacket::handle);
    }
}
