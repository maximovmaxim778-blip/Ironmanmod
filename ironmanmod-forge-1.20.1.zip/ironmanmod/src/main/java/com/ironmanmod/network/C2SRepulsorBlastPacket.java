package com.ironmanmod.network;

import com.ironmanmod.common.SuitAbilityHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: "player pressed the repulsor-blast key". No payload needed. */
public class C2SRepulsorBlastPacket {

    public C2SRepulsorBlastPacket() {
    }

    public static void encode(C2SRepulsorBlastPacket packet, FriendlyByteBuf buffer) {
        // no fields
    }

    public static C2SRepulsorBlastPacket decode(FriendlyByteBuf buffer) {
        return new C2SRepulsorBlastPacket();
    }

    public static void handle(C2SRepulsorBlastPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                SuitAbilityHandler.fireRepulsor(player);
            }
        });
        context.setPacketHandled(true);
    }
}
