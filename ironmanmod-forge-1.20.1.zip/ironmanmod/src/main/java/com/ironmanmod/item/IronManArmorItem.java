package com.ironmanmod.item;

import com.ironmanmod.client.IronManClientArmorHandler;
import com.ironmanmod.registry.ModArmorMaterials;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.function.Consumer;

/**
 * Suit armor piece. Behaviour hooks (flight toggle, repulsor abilities,
 * fall-damage negation, JARVIS voice lines) get wired on top of this in a
 * later pass - for now this focuses on the piece itself plus the model/
 * animation support in client.model.IronManArmorModel.
 *
 * initializeClient() is Forge's supported way to hand a custom armor model
 * to HumanoidArmorLayer without touching client-only classes anywhere the
 * dedicated server would load them: the lambda body only runs client-side.
 */
public class IronManArmorItem extends ArmorItem {

    public IronManArmorItem(Type type, Properties properties) {
        super(ModArmorMaterials.MARK_SUIT, type, properties);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public HumanoidModel<?> getGenericArmorModel(LivingEntity livingEntity, net.minecraft.world.item.ItemStack itemStack,
                                                          net.minecraft.world.entity.EquipmentSlot slot, HumanoidModel<?> original) {
                return IronManClientArmorHandler.modelForSlot(slot);
            }
        });
    }

    /** True while the player is wearing every piece of the Mark suit. */
    public static boolean hasFullSuit(LivingEntity entity) {
        return entity.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).getItem() instanceof IronManArmorItem
                && entity.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST).getItem() instanceof IronManArmorItem
                && entity.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.LEGS).getItem() instanceof IronManArmorItem
                && entity.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET).getItem() instanceof IronManArmorItem;
    }
}
