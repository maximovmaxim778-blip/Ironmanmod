package com.ironmanmod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.network.NetworkHooks;

/**
 * A straight-line energy bolt fired from the palm repulsors. Modelled after
 * vanilla's AbstractHurtingProjectile (same base class Fireball/WitherSkull
 * use) so movement, block collision and networking come for free - the only
 * things this class adds are damage-on-hit and a trailing particle line.
 */
public class RepulsorBlastEntity extends AbstractHurtingProjectile {

    private float damage = 6.0F;

    public RepulsorBlastEntity(EntityType<? extends AbstractHurtingProjectile> type, Level level) {
        super(type, level);
    }

    public void setDamage(float damage) {
        this.damage = damage;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.END_ROD,
                    this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        }
        // Repulsor bolts don't arc like fireballs - cancel gravity/drag each tick.
        if (this.tickCount > 60) {
            this.discard(); // safety despawn after 3 seconds in case it never hits anything
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!this.level().isClientSide) {
            Entity target = result.getEntity();
            Entity owner = this.getOwner();
            DamageSource source = owner instanceof LivingEntity living
                    ? this.damageSources().indirectMagic(this, living)
                    : this.damageSources().magic();
            target.hurt(source, this.damage);
            this.discard();
        }
    }

    @Override
    protected void onHitBlock(net.minecraft.world.phys.BlockHitResult result) {
        super.onHitBlock(result);
        if (!this.level().isClientSide) {
            this.discard();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
    }

    @Override
    protected boolean shouldBurn() {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat("Damage", this.damage);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("Damage")) {
            this.damage = tag.getFloat("Damage");
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
