package com.ironmanmod.common;

import com.ironmanmod.IronManMod;
import com.ironmanmod.entity.RepulsorBlastEntity;
import com.ironmanmod.item.IronManArmorItem;
import com.ironmanmod.network.ModNetwork;
import com.ironmanmod.network.S2CSyncEnergyPacket;
import com.ironmanmod.network.S2CSyncFlyingPacket;
import com.ironmanmod.registry.ModEntityTypes;
import com.ironmanmod.util.JarvisLines;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * All server-side rules for the suit live here: flight toggle, repulsor
 * firing, the energy meter that gates both, fall-damage negation, and the
 * JARVIS lines that accompany each event. Energy is stored directly on the
 * player's persistent NBT so it survives logout/relogin without needing a
 * custom Forge Capability.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MOD_ID)
public final class SuitAbilityHandler {

    private static final String TAG_ENERGY = "ironmanmod_energy";
    private static final String TAG_FLYING = "ironmanmod_flying";
    private static final String TAG_SUITED = "ironmanmod_suited";

    public static final int MAX_ENERGY = 100;
    private static final int FLIGHT_DRAIN_PER_TICK = 1;      // per 5 ticks, see tick handler
    private static final int REPULSOR_COST = 15;
    private static final int REGEN_PER_INTERVAL = 1;
    private static final float REPULSOR_DAMAGE = 6.0F;
    private static final float REPULSOR_SPEED = 2.5F;

    private SuitAbilityHandler() {
    }

    // ---------------------------------------------------------------- energy

    private static int getEnergy(Player player) {
        CompoundTag data = player.getPersistentData();
        return data.contains(TAG_ENERGY) ? data.getInt(TAG_ENERGY) : MAX_ENERGY;
    }

    private static void setEnergy(ServerPlayer player, int value) {
        int clamped = Math.max(0, Math.min(MAX_ENERGY, value));
        player.getPersistentData().putInt(TAG_ENERGY, clamped);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new S2CSyncEnergyPacket(clamped, MAX_ENERGY));
    }

    private static boolean isFlying(Player player) {
        return player.getPersistentData().getBoolean(TAG_FLYING);
    }

    private static void setFlyingFlag(ServerPlayer player, boolean flying) {
        player.getPersistentData().putBoolean(TAG_FLYING, flying);
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player),
                new S2CSyncFlyingPacket(player.getUUID(), flying));
    }

    // -------------------------------------------------------------- actions

    /** Called when the client presses the flight-toggle key. */
    public static void toggleFlight(ServerPlayer player) {
        if (!IronManArmorItem.hasFullSuit(player)) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "The suit needs every piece equipped before flight is available."), true);
            return;
        }

        boolean nowFlying = !isFlying(player);

        if (nowFlying && getEnergy(player) <= 0) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    JarvisLines.random(JarvisLines.LOW_POWER)), true);
            return;
        }

        setFlyingFlag(player, nowFlying);
        player.getAbilities().mayfly = nowFlying || player.getAbilities().instabuild;
        player.getAbilities().flying = nowFlying;
        player.onUpdateAbilities();

        player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                JarvisLines.random(nowFlying ? JarvisLines.FLIGHT_ON : JarvisLines.FLIGHT_OFF)), true);
    }

    /** Called when the client presses the repulsor-blast key. */
    public static void fireRepulsor(ServerPlayer player) {
        if (!IronManArmorItem.hasFullSuit(player)) {
            return;
        }
        if (getEnergy(player) < REPULSOR_COST) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    JarvisLines.random(JarvisLines.LOW_POWER)), true);
            return;
        }
        setEnergy(player, getEnergy(player) - REPULSOR_COST);

        Vec3 look = player.getLookAngle();
        Vec3 origin = player.getEyePosition().add(look.scale(0.6));

        RepulsorBlastEntity blast = new RepulsorBlastEntity(ModEntityTypes.REPULSOR_BLAST.get(), player.level());
        blast.setOwner(player);
        blast.setPos(origin.x, origin.y, origin.z);
        blast.setDeltaMovement(look.scale(REPULSOR_SPEED));
        blast.setDamage(REPULSOR_DAMAGE);
        player.level().addFreshEntity(blast);

        player.level().playSound(null, player.blockPosition(),
                net.minecraft.sounds.SoundEvents.FIREWORK_ROCKET_SHOOT, net.minecraft.sounds.SoundSource.PLAYERS,
                1.0F, 1.6F);

        if (Math.random() < 0.35) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    JarvisLines.random(JarvisLines.REPULSOR_FIRE)), true);
        }
    }

    // --------------------------------------------------------------- events

    /** Full suit negates fall damage entirely (repulsor-assisted landing). */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player player && IronManArmorItem.hasFullSuit(player)) {
            event.setDamageMultiplier(0.0F);
        }
    }

    /** Announces suit status changes (only on the false->true / true->false transition,
     *  so swapping a held item while already suited doesn't spam the message) and cancels
     *  flight if the suit comes off mid-flight. */
    @SubscribeEvent
    public static void onEquipmentChange(LivingEquipmentChangeEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        boolean suitedNow = IronManArmorItem.hasFullSuit(player);
        boolean suitedBefore = player.getPersistentData().getBoolean(TAG_SUITED);
        if (suitedNow == suitedBefore) {
            return;
        }
        player.getPersistentData().putBoolean(TAG_SUITED, suitedNow);

        if (suitedNow) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    JarvisLines.random(JarvisLines.SUIT_ONLINE)), true);
            return;
        }

        if (isFlying(player)) {
            setFlyingFlag(player, false);
            if (!player.getAbilities().instabuild) {
                player.getAbilities().flying = false;
                player.getAbilities().mayfly = false;
                player.onUpdateAbilities();
            }
        }
        player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                JarvisLines.random(JarvisLines.SUIT_REMOVED)), true);
    }

    /** Drains energy while flying, regenerates it otherwise, syncs the HUD periodically. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (player.tickCount % 5 != 0) {
            return; // run this logic every 5 ticks (4x/sec) instead of every tick
        }

        boolean suited = IronManArmorItem.hasFullSuit(player);
        int energy = getEnergy(player);

        if (suited && isFlying(player)) {
            energy -= FLIGHT_DRAIN_PER_TICK;
            if (energy <= 0) {
                energy = 0;
                setFlyingFlag(player, false);
                player.getAbilities().flying = false;
                player.onUpdateAbilities();
                player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                        JarvisLines.random(JarvisLines.LOW_POWER)), true);
            }
        } else if (suited && energy < MAX_ENERGY) {
            energy += REGEN_PER_INTERVAL;
        }

        setEnergy(player, energy);
    }
}
