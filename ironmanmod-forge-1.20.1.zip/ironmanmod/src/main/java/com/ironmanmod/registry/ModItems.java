package com.ironmanmod.registry;

import com.ironmanmod.IronManMod;
import com.ironmanmod.item.IronManArmorItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, IronManMod.MOD_ID);

    public static final RegistryObject<Item> MARK_HELMET = ITEMS.register("mark_helmet",
            () -> new IronManArmorItem(ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> MARK_CHESTPLATE = ITEMS.register("mark_chestplate",
            () -> new IronManArmorItem(ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> MARK_LEGGINGS = ITEMS.register("mark_leggings",
            () -> new IronManArmorItem(ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> MARK_BOOTS = ITEMS.register("mark_boots",
            () -> new IronManArmorItem(ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
}
