package com.ironmanmod.registry;

import com.ironmanmod.IronManMod;
import com.ironmanmod.entity.RepulsorBlastEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntityTypes {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, IronManMod.MOD_ID);

    public static final RegistryObject<EntityType<RepulsorBlastEntity>> REPULSOR_BLAST = ENTITY_TYPES.register(
            "repulsor_blast",
            () -> EntityType.Builder.<RepulsorBlastEntity>of(RepulsorBlastEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(new net.minecraft.resources.ResourceLocation(IronManMod.MOD_ID, "repulsor_blast").toString())
    );
}
