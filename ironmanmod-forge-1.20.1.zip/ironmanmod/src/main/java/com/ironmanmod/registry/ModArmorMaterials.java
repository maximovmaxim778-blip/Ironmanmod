package com.ironmanmod.registry;

import com.ironmanmod.IronManMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumMap;

/**
 * Armor material for the Mark suit: tougher than netherite, repaired with
 * gold ingots (stand-in for the suit's gold-titanium alloy), metallic equip sound.
 */
public enum ModArmorMaterials implements ArmorMaterial {

    MARK_SUIT("mark_suit");

    private static final EnumMap<ArmorItem.Type, Integer> DURABILITY = new EnumMap<>(ArmorItem.Type.class);
    private static final EnumMap<ArmorItem.Type, Integer> DEFENSE = new EnumMap<>(ArmorItem.Type.class);

    static {
        DURABILITY.put(ArmorItem.Type.BOOTS, 15);
        DURABILITY.put(ArmorItem.Type.LEGGINGS, 16);
        DURABILITY.put(ArmorItem.Type.CHESTPLATE, 17);
        DURABILITY.put(ArmorItem.Type.HELMET, 14);

        DEFENSE.put(ArmorItem.Type.BOOTS, 3);
        DEFENSE.put(ArmorItem.Type.LEGGINGS, 6);
        DEFENSE.put(ArmorItem.Type.CHESTPLATE, 8);
        DEFENSE.put(ArmorItem.Type.HELMET, 3);
    }

    private final String name;

    ModArmorMaterials(String name) {
        this.name = name;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return 480 * DURABILITY.getOrDefault(type, 10);
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return DEFENSE.getOrDefault(type, 1);
    }

    @Override
    public int getEnchantmentValue() {
        return 15;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(Items.GOLD_INGOT);
    }

    @Override
    public String getName() {
        return IronManMod.MOD_ID + ":" + name;
    }

    @Override
    public float getToughness() {
        return 4.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.1F;
    }
}
