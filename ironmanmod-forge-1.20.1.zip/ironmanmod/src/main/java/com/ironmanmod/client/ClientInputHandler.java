package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.network.C2SRepulsorBlastPacket;
import com.ironmanmod.network.C2SToggleFlightPacket;
import com.ironmanmod.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Polls the two suit keybinds once per client tick and fires the matching
 * C2S packet. Uses KeyMapping.consumeClick() so held keys don't spam
 * packets - each press sends exactly one message.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MOD_ID, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class ClientInputHandler {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || Minecraft.getInstance().player == null) {
            return;
        }

        while (ModKeyMappings.TOGGLE_FLIGHT.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new C2SToggleFlightPacket());
        }

        while (ModKeyMappings.REPULSOR_BLAST.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new C2SRepulsorBlastPacket());
        }
    }
}
