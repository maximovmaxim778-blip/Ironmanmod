package com.ironmanmod.client;

import com.ironmanmod.entity.RepulsorBlastEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/**
 * No-op visual renderer - the blast's ParticleTypes.END_ROD trail (spawned
 * in RepulsorBlastEntity.tick()) is the actual visual. A renderer class is
 * still required by Forge's entity rendering registry even when there's
 * nothing to draw directly.
 */
public class RepulsorBlastRenderer extends EntityRenderer<RepulsorBlastEntity> {

    public RepulsorBlastRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(RepulsorBlastEntity entity, float entityYaw, float partialTicks,
                        PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        // Intentionally empty - particles carry the visual.
    }

    @Override
    public ResourceLocation getTextureLocation(RepulsorBlastEntity entity) {
        return new ResourceLocation("minecraft", "textures/misc/shadow.png");
    }
}
