package com.ironmanmod.client;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Client-only lookup of "is this entity currently suit-flying", keyed by
 * UUID and kept in sync via S2CSyncFlyingPacket. IronManArmorModel reads
 * this in setupAnim() to decide whether to show the flight pose for ANY
 * nearby player wearing the suit (not just the local one).
 */
public final class FlightRenderState {

    private static final Map<UUID, Boolean> FLYING = new ConcurrentHashMap<>();

    private FlightRenderState() {
    }

    public static void set(UUID id, boolean flying) {
        if (flying) {
            FLYING.put(id, true);
        } else {
            FLYING.remove(id);
        }
    }

    public static boolean isFlying(UUID id) {
        return FLYING.getOrDefault(id, false);
    }
}
