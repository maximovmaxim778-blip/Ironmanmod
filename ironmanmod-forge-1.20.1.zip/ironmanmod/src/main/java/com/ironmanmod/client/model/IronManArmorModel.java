package com.ironmanmod.client.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * Model for the Mark suit armor layer.
 *
 * Extends vanilla HumanoidModel so it plugs straight into HumanoidArmorLayer
 * (same approach every armor mod uses), but adds a handful of extra cubes
 * on top of the base humanoid parts for the suit's silhouette:
 *   - chest arc reactor housing
 *   - shoulder pauldrons
 *   - forearm repulsor housings
 *   - boot thruster fins
 *
 * setupAnim() layers two custom poses on top of the normal walk/attack
 * animation that HumanoidModel already drives:
 *   - "flying" pose: arms sweep back, legs straighten, torso pitches forward
 *     (driven by the entity's fall-flying / elytra state as a stand-in until
 *     the dedicated flight-toggle ability is wired in)
 *   - "repulsor charge" pose: forearms raise and rotate palms forward,
 *     driven by useItemHand / isUsingItem as a placeholder trigger for the
 *     repulsor ability key.
 */
public class IronManArmorModel<T extends LivingEntity> extends HumanoidModel<T> {

    // Extra decorative parts, fetched from the body/arm/leg part trees below.
    private final ModelPart chestReactor;
    private final ModelPart leftPauldron;
    private final ModelPart rightPauldron;
    private final ModelPart leftRepulsor;
    private final ModelPart rightRepulsor;
    private final ModelPart leftBootThruster;
    private final ModelPart rightBootThruster;

    public IronManArmorModel(ModelPart root) {
        super(root);
        this.chestReactor = root.getChild("body").getChild("chest_reactor");
        this.leftPauldron = root.getChild("left_arm").getChild("left_pauldron");
        this.rightPauldron = root.getChild("right_arm").getChild("right_pauldron");
        this.leftRepulsor = root.getChild("left_arm").getChild("left_repulsor");
        this.rightRepulsor = root.getChild("right_arm").getChild("right_repulsor");
        this.leftBootThruster = root.getChild("left_leg").getChild("left_thruster");
        this.rightBootThruster = root.getChild("right_leg").getChild("right_thruster");
    }

    /**
     * Builds the mesh. Base humanoid cubes use CubeDeformation.NONE.grow(0.25f)
     * or similar growth so the suit reads as armor plating over the player
     * model without clipping; extra parts are added as children so they
     * inherit their parent's rotation automatically (e.g. pauldrons follow
     * the arm when it swings or aims).
     */
    public static LayerDefinition createArmorLayer(CubeDeformation deformation, boolean isChestplate) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, deformation),
                PartPose.ZERO);

        // Faceplate detailing (removable visor look) sits slightly proud of the head cube.
        head.addOrReplaceChild("faceplate",
                CubeListBuilder.create().texOffs(32, 0)
                        .addBox(-4.5F, -8.5F, -4.5F, 9.0F, 9.0F, 1.0F, deformation),
                PartPose.ZERO);

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16)
                        .addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, deformation),
                PartPose.ZERO);

        // Arc reactor housing: small raised cube centered on the chest.
        body.addOrReplaceChild("chest_reactor",
                CubeListBuilder.create().texOffs(0, 32)
                        .addBox(-1.5F, 2.0F, -2.6F, 3.0F, 3.0F, 1.0F, CubeDeformation.NONE),
                PartPose.ZERO);

        PartDefinition rightArm = root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16)
                        .addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, deformation),
                PartPose.ZERO);

        rightArm.addOrReplaceChild("right_pauldron",
                CubeListBuilder.create().texOffs(40, 32)
                        .addBox(-4.0F, -3.5F, -3.0F, 6.0F, 4.0F, 6.0F, CubeDeformation.NONE.extend(0.1F)),
                PartPose.ZERO);

        rightArm.addOrReplaceChild("right_repulsor",
                CubeListBuilder.create().texOffs(0, 37)
                        .addBox(-2.5F, 8.5F, -2.5F, 5.0F, 1.0F, 5.0F, CubeDeformation.NONE),
                PartPose.ZERO);

        PartDefinition leftArm = root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(40, 16).mirror()
                        .addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, deformation),
                PartPose.ZERO);

        leftArm.addOrReplaceChild("left_pauldron",
                CubeListBuilder.create().texOffs(40, 32).mirror()
                        .addBox(-2.0F, -3.5F, -3.0F, 6.0F, 4.0F, 6.0F, CubeDeformation.NONE.extend(0.1F)),
                PartPose.ZERO);

        leftArm.addOrReplaceChild("left_repulsor",
                CubeListBuilder.create().texOffs(0, 37).mirror()
                        .addBox(-2.5F, 8.5F, -2.5F, 5.0F, 1.0F, 5.0F, CubeDeformation.NONE),
                PartPose.ZERO);

        PartDefinition rightLeg = root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, deformation),
                PartPose.ZERO);

        rightLeg.addOrReplaceChild("right_thruster",
                CubeListBuilder.create().texOffs(20, 37)
                        .addBox(-2.5F, 10.0F, -2.5F, 5.0F, 2.0F, 5.0F, CubeDeformation.NONE.extend(0.15F)),
                PartPose.ZERO);

        PartDefinition leftLeg = root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, 16).mirror()
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, deformation),
                PartPose.ZERO);

        leftLeg.addOrReplaceChild("left_thruster",
                CubeListBuilder.create().texOffs(20, 37).mirror()
                        .addBox(-2.5F, 10.0F, -2.5F, 5.0F, 2.0F, 5.0F, CubeDeformation.NONE.extend(0.15F)),
                PartPose.ZERO);

        // Hats/second-layer slots (unused decoratively here but required by HumanoidModel).
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }

    /**
     * Mirrors vanilla HumanoidArmorLayer's part-visibility logic: hide every
     * part, then reveal only the ones this equipment slot renders, so a
     * helmet-only render doesn't drag the chestplate cubes along with it.
     */
    public void setVisibleForSlot(EquipmentSlot slot) {
        this.setAllVisible(false);
        switch (slot) {
            case HEAD -> {
                this.head.visible = true;
                this.hat.visible = true;
            }
            case CHEST -> {
                this.body.visible = true;
                this.rightArm.visible = true;
                this.leftArm.visible = true;
            }
            case LEGS -> {
                this.body.visible = true;
                this.rightLeg.visible = true;
                this.leftLeg.visible = true;
            }
            case FEET -> {
                this.rightLeg.visible = true;
                this.leftLeg.visible = true;
            }
            default -> {
            }
        }
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                           float netHeadYaw, float headPitch) {
        // Run the normal humanoid walk/idle/attack animation first...
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        boolean flying = entity.isFallFlying() || com.ironmanmod.client.FlightRenderState.isFlying(entity.getUUID());
        boolean charging = entity.isUsingItem();

        applyFlightPose(flying, ageInTicks);
        applyRepulsorPose(charging);
    }

    /**
     * Superman-style flight pose: arms sweep back and slightly out, legs
     * straighten and trail behind, head levels off. Blends toward the pose
     * rather than snapping, so it reads as a takeoff/landing transition.
     */
    private void applyFlightPose(boolean flying, float ageInTicks) {
        if (!flying) {
            return;
        }
        float wobble = Mth.sin(ageInTicks * 0.15F) * 0.05F;

        this.rightArm.xRot = -1.4F + wobble;
        this.rightArm.zRot = 0.15F;
        this.leftArm.xRot = -1.4F - wobble;
        this.leftArm.zRot = -0.15F;

        this.rightLeg.xRot = 0.35F;
        this.leftLeg.xRot = 0.35F;

        this.body.xRot = 0.55F;
        this.head.xRot = -0.35F;

        // Boot thrusters flare out slightly while flying.
        this.leftBootThruster.xRot = -0.2F;
        this.rightBootThruster.xRot = -0.2F;
    }

    /**
     * Repulsor charge pose: raises whichever forearm(s) correspond to the
     * active hand and angles the palm forward. Placeholder trigger
     * (isUsingItem) until the dedicated repulsor-blast ability replaces it.
     */
    private void applyRepulsorPose(boolean charging) {
        if (!charging) {
            return;
        }
        this.rightArm.xRot = -1.2F;
        this.rightArm.yRot = -0.2F;
        this.rightRepulsor.xRot = 0.3F;
    }
}
