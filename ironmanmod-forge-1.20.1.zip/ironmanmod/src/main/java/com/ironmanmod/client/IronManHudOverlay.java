package com.ironmanmod.client;

import com.ironmanmod.item.IronManArmorItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * Bottom-left energy readout, only drawn while the local player is wearing
 * the full suit. Values are pushed from the server via S2CSyncEnergyPacket;
 * this class just holds the latest numbers and paints a simple bar + label.
 */
public class IronManHudOverlay implements IGuiOverlay {

    private static int energy = 100;
    private static int maxEnergy = 100;

    public static void setEnergy(int current, int max) {
        energy = current;
        maxEnergy = max;
    }

    @Override
    public void render(net.minecraftforge.client.gui.overlay.ForgeGui gui, GuiGraphics graphics,
                        float partialTick, int screenWidth, int screenHeight) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || !IronManArmorItem.hasFullSuit(player)) {
            return;
        }

        int barWidth = 100;
        int barHeight = 6;
        int x = 10;
        int y = screenHeight - 30;

        float ratio = maxEnergy == 0 ? 0 : (float) energy / (float) maxEnergy;
        int fillWidth = Math.round(barWidth * ratio);

        int barColor = ratio > 0.3F ? 0xFF33CFEA : 0xFFE04B3B; // cyan normally, red when low

        graphics.fill(x, y, x + barWidth, y + barHeight, 0x88000000);
        graphics.fill(x, y, x + fillWidth, y + barHeight, barColor);
        graphics.drawString(Minecraft.getInstance().font, "ARC REACTOR", x, y - 10, 0xFFFFFFFF, true);
    }
}
