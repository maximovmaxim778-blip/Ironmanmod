package com.ironmanmod.client;

import com.ironmanmod.client.model.IronManArmorModel;
import net.minecraft.world.entity.EquipmentSlot;

/**
 * Tiny static holder for the two baked model instances. Kept separate from
 * ClientModEvents so IronManArmorItem.initializeClient() has a single,
 * obviously-client-only place to pull the right model from.
 */
public final class IronManClientArmorHandler {

    private static IronManArmorModel<?> outerModel;
    private static IronManArmorModel<?> innerModel;

    private IronManClientArmorHandler() {
    }

    public static void init(IronManArmorModel<?> outer, IronManArmorModel<?> inner) {
        outerModel = outer;
        innerModel = inner;
    }

    /** Leggings use the thinner "inner" mesh; every other slot uses "outer". */
    public static IronManArmorModel<?> modelForSlot(EquipmentSlot slot) {
        IronManArmorModel<?> model = (slot == EquipmentSlot.LEGS) ? innerModel : outerModel;
        model.setVisibleForSlot(slot);
        return model;
    }
}
