package com.ironmanmod.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;

/** Keybinds shown in Controls > Iron Man Mod. Both remappable by the player. */
public final class ModKeyMappings {

    public static final String CATEGORY = "key.categories.ironmanmod";

    public static final KeyMapping TOGGLE_FLIGHT = new KeyMapping(
            "key.ironmanmod.toggle_flight", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, InputConstants.KEY_V, CATEGORY);

    public static final KeyMapping REPULSOR_BLAST = new KeyMapping(
            "key.ironmanmod.repulsor_blast", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, InputConstants.KEY_R, CATEGORY);

    private ModKeyMappings() {
    }
}
