package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.client.model.IronManArmorModel;
import com.ironmanmod.registry.ModEntityTypes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Client-only setup: mesh layers, keybinds, HUD overlay, entity renderer,
 * and baking the two armor model instances that IronManClientArmorHandler
 * hands out at render time.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class ClientModEvents {

    public static final ModelLayerLocation OUTER_LAYER =
            new ModelLayerLocation(new ResourceLocation(IronManMod.MOD_ID, "mark_suit_outer"), "main");
    public static final ModelLayerLocation INNER_LAYER =
            new ModelLayerLocation(new ResourceLocation(IronManMod.MOD_ID, "mark_suit_inner"), "main");

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(OUTER_LAYER, () -> IronManArmorModel.createArmorLayer(new CubeDeformation(1.0F), true));
        event.registerLayerDefinition(INNER_LAYER, () -> IronManArmorModel.createArmorLayer(new CubeDeformation(0.5F), false));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntityTypes.REPULSOR_BLAST.get(), RepulsorBlastRenderer::new);
    }

    @SubscribeEvent
    public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(ModKeyMappings.TOGGLE_FLIGHT);
        event.register(ModKeyMappings.REPULSOR_BLAST);
    }

    @SubscribeEvent
    public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll("ironman_energy", new IronManHudOverlay());
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            IronManArmorModel<?> outer = new IronManArmorModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(OUTER_LAYER));
            IronManArmorModel<?> inner = new IronManArmorModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(INNER_LAYER));
            IronManClientArmorHandler.init(outer, inner);
        });
    }
}
