package com.ironmanmod.util;

import java.util.List;
import java.util.Random;

/**
 * Original flavor-text lines for the suit's onboard assistant, shown as
 * action-bar messages. Deliberately NOT copied from any film script -
 * written fresh in the spirit of a dry, formal AI butler.
 *
 * If you want an actual spoken voice, generate short .ogg lines yourself
 * (e.g. with a TTS tool of your choice) matching these lines, drop them in
 * assets/ironmanmod/sounds/jarvis/, and list them in sounds.json - the code
 * only wires up the *text* side, since I can't produce audio.
 */
public final class JarvisLines {

    private static final Random RANDOM = new Random();

    public static final List<String> SUIT_ONLINE = List.of(
            "Systems online. All plating nominal.",
            "Good to see you again. Diagnostics complete.",
            "Suit power at full capacity."
    );

    public static final List<String> FLIGHT_ON = List.of(
            "Flight systems engaged.",
            "Thrusters online. Mind the ceiling.",
            "Taking us up."
    );

    public static final List<String> FLIGHT_OFF = List.of(
            "Flight systems disengaged.",
            "Thrusters offline.",
            "Bringing us back down."
    );

    public static final List<String> REPULSOR_FIRE = List.of(
            "Repulsor discharged.",
            "Firing.",
            "Target acquired."
    );

    public static final List<String> LOW_POWER = List.of(
            "Power reserves critical. Recommend landing.",
            "Warning: energy levels low.",
            "We're running low on power."
    );

    public static final List<String> SUIT_REMOVED = List.of(
            "Suit powering down. Standing by.",
            "Going offline. Call if you need me."
    );

    private JarvisLines() {
    }

    public static String random(List<String> pool) {
        return pool.get(RANDOM.nextInt(pool.size()));
    }
}
