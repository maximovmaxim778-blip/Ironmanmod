package com.ironmanmod;

import com.ironmanmod.registry.ModEntityTypes;
import com.ironmanmod.registry.ModItems;
import com.ironmanmod.network.ModNetwork;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.RegistryObject;

/**
 * Main entry point of the Iron Man mod.
 * Registers items (armor), entities (repulsor blast) and the network
 * channel, and hooks the armor into the creative "combat" tab.
 * Client-only rendering/model/HUD/input setup lives under client.*;
 * server-side ability rules (flight, repulsor, energy) live in common.SuitAbilityHandler.
 */
@Mod(IronManMod.MOD_ID)
public class IronManMod {

    public static final String MOD_ID = "ironmanmod";

    public IronManMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modEventBus);
        ModEntityTypes.ENTITY_TYPES.register(modEventBus);

        ModNetwork.register();

        modEventBus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            for (RegistryObject<net.minecraft.world.item.Item> item : ModItems.ITEMS.getEntries()) {
                event.accept(new ItemStack(item.get()));
            }
        }
    }
}
